=== Mining the Insights of SDOS =======

Jupyter notebook is runnable. Simply do "run all cells".
For uninterrupted results, open them using jupyter lab.


You need to have the dataset in the same directory of the code.
Link to dataset: https://insights.stackoverflow.com/survey

The result folder contains key results.

